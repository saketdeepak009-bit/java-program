import java.util.Scanner;

public class nine {
    public static void main(String[] args) {
        
        float a = 7/4.0f*9/2.0f;
        System.out.println(a);

        char grade = 'B';
        grade = (char) (grade + 8);
        System.out.println(grade);


        // Decrypting the grade



        grade = (char) (grade - 8);
        System.out.println(grade);

     Scanner input = new Scanner(System.in);
    int n = input.nextInt();
     System.out.println(n>8);


     System.out.println(7*49/7+35/5);

    

    }
    
}
