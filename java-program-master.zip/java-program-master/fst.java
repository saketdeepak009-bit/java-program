class fst{
    public static void main (String a[]){
        System.out.println(" this is my first program in java ");
    }
}