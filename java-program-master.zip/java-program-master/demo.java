
public class demo{
    public static void main (String a[])
    {
        // write your code here
        System.out.println("hello world ");
    }
}
     // add to number 
     //AddTwoNumber --pascal naming convention    <<class
    //  addTwoNumber --camel case naming conventuion   <<function