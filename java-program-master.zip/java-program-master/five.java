import java.util.Scanner;

public class five {

    public static void main(String[] args) {
       // float hindi  = 59;
       // float english  =41;
       // float math =45;
       // float chemistry =70;
        //float  physics =30;
       // float cgpa =(hindi + english + math + chemistry + physics)/50;
       // System.out.println(cgpa);


       // question no. 2

       //
        //System.out.println("hello "  + name + " have a good day!");


        // quetion no.3


         System.out.println("enter your number");
        Scanner input = new Scanner(System.in);
        System.out.println(input.next());
        




       

    }
}
