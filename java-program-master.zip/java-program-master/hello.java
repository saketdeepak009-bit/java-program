

public class hello{
    public static void main(String[] args) {
        int a = 1;
        while(a<=10){
            System.out.println(a);
            a++;
        }
        int c = 1;
        do  {
            System.out.println(c);
            c++;

        }while(c<=6);

        

    }

}
    

