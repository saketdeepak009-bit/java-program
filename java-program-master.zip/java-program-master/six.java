public class six {
    public static void main(String[] args) {
        // 1. Arithmetic operator
        int a = 5;
        int b = 5+a;
        System.out.println(b);
        int a1 = 50;
        int b1 = 100-a1;
        System.out.println(b1);
        int a2 = 10;
        int b2 = 10*a2;
        System.out.println(b2);
        int a3 = 10;
        int b3 = 1500/a3; 
        System.out.println(b3);
        int a4 = 6;
        int b4 = 14%a4;  // modulo aperator
        System.out.println(b4);

           // 2. Assignment operator

        int p = 5;
         p +=  5; 
         System.out.println(p);
         int q = 100;
         q -= 10;
         System.out.println(q);
         int r = 20;
         r *= 10;
         System.out.println(r);
         int s = 200;
         s /= 20;
         System.out.println(s);



        // 3. comparision operator

        System.out.println(5==5);
        System.out.println(6<=4);
        System.out.println(7>=3);
        System.out.println(100<=90);


       // 4. logical operator


       System.out.println(65>5 && 65>60);
       System.out.println(100<5 && 100>5);
       System.out.println(25>30 && 30>35);



       // 5. bitwise operator



       //   10
       //   11
       //  ------- 
       //   10

       System.out.println(2&3);
       System.out.println(4&6);
       System.out.println(5&20);




        

        
    }
    
}
