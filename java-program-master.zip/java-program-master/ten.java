import java.util.Scanner;

public class ten {

    public static void main(String[] args) {

       // String name = new String("Harry");

       String name = "harry";

        System.out.println(name);
        System .out.print("the name is:");
        System.out.print(name);

        int a = 16;
        float b = 15.5f;
        System.out.printf("the valuen of a is %d and the value of b is %f ",a,b );
       // System.out.format("the valuen of a is %d and the value of b is %f ",a,b );

       Scanner sc = new Scanner(System.in);

       String st = sc.nextLine();
       System.out.println(st);


    }
    
}
