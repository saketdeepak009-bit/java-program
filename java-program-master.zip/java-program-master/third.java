public class third {
    public static void main(String[] args) {
        byte age = 35;
        int age2 = 95;
        short st =80;
        long age3 = 100;

        //System.out.println(age2);
        char ch = 'd';
        float f1 = 10.7f;
        double d1 = 4.770;
        boolean b = true;
        String s = "dipak";


        System.out.println(age);
        System.out.println(ch);
        System.out.println(st);
        System.out.println(age3);
        System.out.println(f1);
        System.out.println(age2);
        System.out.println(d1);
        System.out.println(age2);
        System.out.println(b);
        System.out.println(s);




    }
    
}
