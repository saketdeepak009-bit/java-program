public class second{
    public static void main(String[] args)
    {
// write your code here 
    
    System.out.println("the sum of these numbers is");
    int num1 = 10;
    int num2 = 12;
    int num3 = 13;
    int sum = num1 + num2 + num3;
    System.out.println(sum);
    }
}


