import java.util.Scanner;

public class fourth {
    
    public static void main(String[] args) {
        System.out.println("It work!");
        System.out.println("taking Input from the user");
        Scanner sc = new Scanner(System.in);
       // System.out.println("enter number 1");
       // int a = sc.nextInt();

      // boolean b1 = sc.hasNextInt();
     //  System.out.println(b1);

        //float a = sc.nextFloat();
       // System.out.println("enter number 2");
       // int b = sc.nextInt()
       // float b = sc.nextFloat();
       // int sum = a+b;
      // float sum = a+b;
        //System.out.println("the sum of these numbers is");
       // System.out.println(sum);
        String str = sc.nextLine();
        System.out.println(str);


    }
}
         
    
